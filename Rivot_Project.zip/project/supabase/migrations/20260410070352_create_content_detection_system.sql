/*
  # AI-Based Riots Provoking Content Detection System Schema

  ## Overview
  This migration sets up the database for a content detection system that analyzes
  text, URLs, and captions for harmful or riot-provoking content.

  ## New Tables

  ### 1. `detection_results`
  Stores all content analysis results with risk scores and category breakdowns.
  - `id` - Unique identifier
  - `content_type` - Type of content: 'text', 'url', 'caption', 'email', 'message'
  - `input_content` - The original content submitted for analysis
  - `source_url` - Optional URL if content came from a website
  - `risk_score` - Risk percentage 0-100
  - `risk_level` - 'safe', 'low', 'moderate', 'high', 'critical'
  - `categories` - JSON breakdown of detected categories and their scores
  - `summary` - AI-generated summary of findings
  - `is_flagged` - Whether content was flagged for review
  - `word_count` - Number of words analyzed
  - `created_at` - Timestamp of detection

  ### 2. `user_preferences`
  Stores user content filtering and notification preferences.
  - `id` - Unique identifier
  - `user_session` - Session identifier (supports anonymous users)
  - `allowed_categories` - JSON array of content categories user allows
  - `alert_threshold` - Risk score percentage that triggers alerts
  - `blocked_keywords` - JSON array of custom blocked keywords
  - `content_filters` - JSON object of filter settings
  - `website_whitelist` - JSON array of trusted websites
  - `website_blacklist` - JSON array of blocked websites

  ### 3. `website_scans`
  Stores website scanning results for URL-based analysis.
  - `id` - Unique identifier
  - `url` - The URL that was scanned
  - `domain` - Extracted domain name
  - `overall_risk_score` - Aggregate risk score for the site
  - `risk_level` - Overall risk classification
  - `pages_scanned` - Number of pages analyzed
  - `status` - 'pending', 'completed', 'failed'
  - `scan_results` - JSON detailed results per section

  ## Security
  - RLS enabled on all tables
  - Public read/write for anonymous usage (content moderation tool)
  - Admin-level policies for deletion
*/

CREATE TABLE IF NOT EXISTS detection_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  content_type text NOT NULL DEFAULT 'text',
  input_content text NOT NULL,
  source_url text,
  risk_score integer NOT NULL DEFAULT 0,
  risk_level text NOT NULL DEFAULT 'safe',
  categories jsonb DEFAULT '[]',
  summary text DEFAULT '',
  keywords_detected jsonb DEFAULT '[]',
  is_flagged boolean DEFAULT false,
  word_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE detection_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert detection results"
  ON detection_results FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can read detection results"
  ON detection_results FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Authenticated users can delete detection results"
  ON detection_results FOR DELETE
  TO authenticated
  USING (true);

CREATE TABLE IF NOT EXISTS user_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_session text NOT NULL DEFAULT 'default',
  allowed_categories jsonb DEFAULT '["news", "education", "social"]',
  alert_threshold integer DEFAULT 50,
  blocked_keywords jsonb DEFAULT '[]',
  content_filters jsonb DEFAULT '{"violence": true, "hate_speech": true, "riot_provocation": true, "threats": true, "extremism": true, "harassment": true, "misinformation": true}',
  website_whitelist jsonb DEFAULT '[]',
  website_blacklist jsonb DEFAULT '[]',
  notifications_enabled boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_preferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read preferences"
  ON user_preferences FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can insert preferences"
  ON user_preferences FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can update preferences"
  ON user_preferences FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE TABLE IF NOT EXISTS website_scans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL,
  domain text,
  overall_risk_score integer DEFAULT 0,
  risk_level text DEFAULT 'safe',
  pages_scanned integer DEFAULT 1,
  status text DEFAULT 'completed',
  scan_results jsonb DEFAULT '{}',
  is_recommended boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE website_scans ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert website scans"
  ON website_scans FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone can read website scans"
  ON website_scans FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE INDEX IF NOT EXISTS idx_detection_results_created_at ON detection_results(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_detection_results_risk_level ON detection_results(risk_level);
CREATE INDEX IF NOT EXISTS idx_detection_results_is_flagged ON detection_results(is_flagged);
CREATE INDEX IF NOT EXISTS idx_website_scans_domain ON website_scans(domain);
CREATE INDEX IF NOT EXISTS idx_user_preferences_session ON user_preferences(user_session);

INSERT INTO user_preferences (user_session, allowed_categories, alert_threshold, content_filters)
VALUES (
  'default',
  '["news", "education", "social", "entertainment"]',
  50,
  '{"violence": true, "hate_speech": true, "riot_provocation": true, "threats": true, "extremism": true, "harassment": true, "misinformation": true}'
)
ON CONFLICT DO NOTHING;
