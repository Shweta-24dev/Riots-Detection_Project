import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface AnalysisCategory {
  name: string;
  score: number;
  detected_terms: string[];
  weight: number;
}

interface AnalysisResult {
  risk_score: number;
  risk_level: string;
  categories: AnalysisCategory[];
  summary: string;
  keywords_detected: string[];
  word_count: number;
  recommendation: string;
}

const CATEGORY_PATTERNS: Record<string, { terms: string[]; weight: number; label: string }> = {
  riot_provocation: {
    label: "Riot Provocation",
    weight: 2.5,
    terms: [
      "riot", "uprising", "revolt", "insurrection", "rebel", "overthrow", "take to the streets",
      "mobilize", "gather force", "storm", "siege", "take down", "tear down", "burn it down",
      "burn down", "revolution now", "rise up", "fight back", "take over", "march on",
      "besiege", "occupy", "blockade", "seize", "topple", "bring down", "armed resistance",
      "civil unrest", "mass protest", "violent protest", "confront", "attack the"
    ],
  },
  violence: {
    label: "Violence & Physical Harm",
    weight: 2.2,
    terms: [
      "kill", "murder", "attack", "assault", "beat", "shoot", "stab", "bomb", "explode",
      "weapon", "gun", "knife", "blow up", "destroy", "massacre", "slaughter", "execute",
      "eliminate", "annihilate", "wipe out", "bloodshed", "violent", "brutalize",
      "torture", "harm", "hurt", "injure", "wound", "maim", "dismember",
      "armed attack", "physical force", "street fight", "gang war"
    ],
  },
  hate_speech: {
    label: "Hate Speech",
    weight: 2.0,
    terms: [
      "hate", "racist", "racism", "bigot", "bigotry", "supremacy", "inferior race",
      "discrimination", "slur", "dehumanize", "vermin", "parasite", "infestation",
      "ethnic cleansing", "genocide", "exterminate", "purge", "subhuman",
      "inferior people", "invaders", "replace us", "they will not replace",
      "white power", "racial purity", "religious persecution"
    ],
  },
  threats: {
    label: "Threats & Intimidation",
    weight: 1.8,
    terms: [
      "threaten", "threat", "warn you", "you will pay", "consequences", "retaliate",
      "revenge", "beware", "watch your back", "you will regret", "make you suffer",
      "hunt you down", "find you", "coming for you", "pay the price",
      "retribution", "punish", "punishment awaits", "you have been warned",
      "last warning", "final warning", "or else"
    ],
  },
  extremism: {
    label: "Extremist Content",
    weight: 2.3,
    terms: [
      "extremist", "radical", "terrorist", "terrorism", "jihad", "holy war",
      "infidel", "crusade", "martyr", "sacrifice yourself", "die for the cause",
      "glory of death", "sleeper cell", "lone wolf", "radicalize",
      "domestic terrorism", "foreign fighters", "caliphate", "zealot",
      "fanatic", "extremism", "fringe group", "death to", "destroy the state"
    ],
  },
  harassment: {
    label: "Harassment & Stalking",
    weight: 1.5,
    terms: [
      "harass", "harassment", "bully", "bullying", "stalk", "stalking",
      "doxx", "doxing", "expose personal info", "swat", "swatting",
      "intimidate", "humiliate publicly", "destroy reputation",
      "make their life hell", "ruin them", "get them fired",
      "find their address", "follow them", "track them"
    ],
  },
  misinformation: {
    label: "Misinformation & Propaganda",
    weight: 1.3,
    terms: [
      "fake news", "hoax", "conspiracy", "propaganda", "lies", "cover up",
      "they dont want you to know", "hidden truth", "wake up sheeple",
      "deep state", "government lies", "mainstream media lies",
      "false flag", "staged event", "crisis actor", "plandemic",
      "they are hiding", "the truth is", "exposing the truth",
      "official narrative is false", "corrupt system"
    ],
  },
  incitement: {
    label: "Incitement to Action",
    weight: 2.0,
    terms: [
      "we must act now", "no time to wait", "take action", "do something now",
      "enough is enough", "time to fight", "fight for your rights",
      "they leave us no choice", "forced to act", "defend yourself",
      "stand your ground", "arm yourself", "prepare for war",
      "join us now", "recruit", "spread this message", "share before deleted",
      "go viral", "share everywhere", "this cannot wait"
    ],
  },
};

const SAFE_CONTEXT_TERMS = [
  "peace", "peaceful", "non-violent", "unity", "harmony", "dialogue",
  "negotiation", "mediation", "understanding", "compassion", "tolerance",
  "democracy", "freedom of speech", "human rights", "justice",
  "awareness", "education", "research", "study", "analysis", "report",
  "documentary", "historical", "academic", "prevent", "prevention", "safety"
];

function normalizeText(text: string): string {
  return text.toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function analyzeText(text: string): AnalysisResult {
  const normalized = normalizeText(text);
  const words = normalized.split(' ').filter(w => w.length > 0);
  const wordCount = words.length;

  const safeContextScore = SAFE_CONTEXT_TERMS.filter(term =>
    normalized.includes(term)
  ).length;
  const safeContextMultiplier = Math.max(0.5, 1 - (safeContextScore * 0.05));

  const categories: AnalysisCategory[] = [];
  const allDetectedTerms: string[] = [];

  for (const [key, config] of Object.entries(CATEGORY_PATTERNS)) {
    const detectedTerms: string[] = [];

    for (const term of config.terms) {
      if (normalized.includes(term)) {
        detectedTerms.push(term);
        if (!allDetectedTerms.includes(term)) {
          allDetectedTerms.push(term);
        }
      }
    }

    if (detectedTerms.length > 0) {
      const rawScore = Math.min(100, (detectedTerms.length / config.terms.length) * 100 * config.weight * 3);
      const adjustedScore = Math.round(rawScore * safeContextMultiplier);

      categories.push({
        name: config.label,
        score: Math.min(100, adjustedScore),
        detected_terms: detectedTerms,
        weight: config.weight,
      });
    }
  }

  let riskScore = 0;
  if (categories.length > 0) {
    const weightedSum = categories.reduce((sum, cat) => sum + cat.score * cat.weight, 0);
    const totalWeight = categories.reduce((sum, cat) => sum + cat.weight, 0);
    riskScore = Math.round(weightedSum / totalWeight);

    if (categories.length > 2) {
      riskScore = Math.min(100, riskScore + (categories.length - 2) * 5);
    }
  }

  riskScore = Math.max(0, Math.min(100, Math.round(riskScore * safeContextMultiplier)));

  let riskLevel: string;
  let recommendation: string;
  let summary: string;

  if (riskScore >= 80) {
    riskLevel = "critical";
    recommendation = "This content poses a critical risk. Immediate action recommended. Do not share or engage with this content.";
  } else if (riskScore >= 60) {
    riskLevel = "high";
    recommendation = "High-risk content detected. This content may incite violence or civil unrest. Exercise extreme caution.";
  } else if (riskScore >= 40) {
    riskLevel = "moderate";
    recommendation = "Moderate risk detected. Content contains potentially harmful elements. Verify sources before sharing.";
  } else if (riskScore >= 20) {
    riskLevel = "low";
    recommendation = "Low risk content. Some concerning elements detected but context appears benign. Monitor for patterns.";
  } else {
    riskLevel = "safe";
    recommendation = "Content appears safe. No significant harmful elements detected.";
  }

  const categoryNames = categories.map(c => c.name).join(", ");

  if (categories.length === 0) {
    summary = "No harmful content patterns detected. The analyzed content appears to be safe and does not contain indicators of violence, hate speech, or riot provocation.";
  } else if (riskScore >= 80) {
    summary = `CRITICAL ALERT: This content contains highly dangerous material. Detected categories: ${categoryNames}. A total of ${allDetectedTerms.length} harmful terms were identified. This content has strong indicators of riot provocation and could lead to civil unrest.`;
  } else if (riskScore >= 60) {
    summary = `HIGH RISK: Significant harmful content detected across ${categories.length} categories: ${categoryNames}. Found ${allDetectedTerms.length} flagged terms. This content requires immediate review before any distribution.`;
  } else if (riskScore >= 40) {
    summary = `MODERATE RISK: Content shows concerning patterns in ${categories.length} area(s): ${categoryNames}. ${allDetectedTerms.length} potentially harmful terms detected. Context suggests possible harmful intent.`;
  } else {
    summary = `LOW RISK: Minor concerning elements found in ${categories.length} category: ${categoryNames}. ${allDetectedTerms.length} terms flagged for review. Overall context appears relatively safe but warrants attention.`;
  }

  return {
    risk_score: riskScore,
    risk_level: riskLevel,
    categories: categories.sort((a, b) => b.score - a.score),
    summary,
    keywords_detected: allDetectedTerms,
    word_count: wordCount,
    recommendation,
  };
}

async function fetchAndAnalyzeUrl(url: string): Promise<{ content: string; title: string; error?: string }> {
  try {
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; ContentAnalyzer/1.0)",
        "Accept": "text/html,application/xhtml+xml",
      },
      signal: AbortSignal.timeout(10000),
    });

    if (!response.ok) {
      return { content: "", title: url, error: `HTTP ${response.status}` };
    }

    const html = await response.text();

    const titleMatch = html.match(/<title[^>]*>([^<]+)<\/title>/i);
    const title = titleMatch ? titleMatch[1].trim() : url;

    const cleaned = html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 5000);

    return { content: cleaned, title };
  } catch (err) {
    return { content: "", title: url, error: err instanceof Error ? err.message : "Failed to fetch URL" };
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const body = await req.json();
    const { content, content_type, url } = body;

    let textToAnalyze = content || "";
    let sourceTitle = "";

    if (content_type === "url" && url) {
      const fetched = await fetchAndAnalyzeUrl(url);
      if (fetched.error && !fetched.content) {
        return new Response(
          JSON.stringify({ error: `Could not fetch URL: ${fetched.error}` }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      textToAnalyze = fetched.content;
      sourceTitle = fetched.title;
    }

    if (!textToAnalyze || textToAnalyze.trim().length === 0) {
      return new Response(
        JSON.stringify({ error: "No content provided for analysis" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const result = analyzeText(textToAnalyze);

    return new Response(
      JSON.stringify({ ...result, source_title: sourceTitle }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err instanceof Error ? err.message : "Analysis failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
