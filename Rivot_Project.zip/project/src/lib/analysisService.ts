import { supabase, EDGE_FUNCTION_URL } from './supabase';
import type { DetectionResult, ContentType, UserPreferences } from '../types';

export async function analyzeContent(
  content: string,
  contentType: ContentType,
  url?: string
): Promise<DetectionResult> {
  const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

  const response = await fetch(EDGE_FUNCTION_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${anonKey}`,
      'Apikey': anonKey,
    },
    body: JSON.stringify({ content, content_type: contentType, url }),
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error || 'Analysis failed');
  }

  const data = await response.json();

  const result: DetectionResult = {
    content_type: contentType,
    input_content: url || content.slice(0, 500),
    source_url: url,
    risk_score: data.risk_score,
    risk_level: data.risk_level,
    categories: data.categories || [],
    summary: data.summary,
    keywords_detected: data.keywords_detected || [],
    is_flagged: data.risk_score >= 60,
    word_count: data.word_count,
    recommendation: data.recommendation,
  };

  await saveDetectionResult(result);
  return result;
}

export async function saveDetectionResult(result: DetectionResult): Promise<void> {
  await supabase.from('detection_results').insert({
    content_type: result.content_type,
    input_content: result.input_content,
    source_url: result.source_url,
    risk_score: result.risk_score,
    risk_level: result.risk_level,
    categories: result.categories,
    summary: result.summary,
    keywords_detected: result.keywords_detected,
    is_flagged: result.is_flagged,
    word_count: result.word_count,
  });
}

export async function fetchDetectionHistory(limit = 50) {
  const { data, error } = await supabase
    .from('detection_results')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(limit);

  if (error) throw error;
  return data || [];
}

export async function fetchDashboardStats() {
  const { data, error } = await supabase
    .from('detection_results')
    .select('risk_score, risk_level, is_flagged, content_type');

  if (error) throw error;

  const results = data || [];
  const total = results.length;
  const flagged = results.filter(r => r.is_flagged).length;
  const safe = results.filter(r => r.risk_level === 'safe').length;
  const critical = results.filter(r => r.risk_level === 'critical').length;
  const avgScore = total > 0
    ? Math.round(results.reduce((sum, r) => sum + r.risk_score, 0) / total)
    : 0;

  const { data: siteData } = await supabase
    .from('website_scans')
    .select('id', { count: 'exact' });

  return {
    total_scans: total,
    flagged_content: flagged,
    safe_content: safe,
    avg_risk_score: avgScore,
    critical_alerts: critical,
    websites_scanned: siteData?.length || 0,
  };
}

export async function getUserPreferences(): Promise<UserPreferences> {
  const { data } = await supabase
    .from('user_preferences')
    .select('*')
    .eq('user_session', 'default')
    .maybeSingle();

  return data || {
    user_session: 'default',
    allowed_categories: ['news', 'education', 'social', 'entertainment'],
    alert_threshold: 50,
    blocked_keywords: [],
    content_filters: {
      violence: true,
      hate_speech: true,
      riot_provocation: true,
      threats: true,
      extremism: true,
      harassment: true,
      misinformation: true,
    },
    website_whitelist: [],
    website_blacklist: [],
    notifications_enabled: true,
  };
}

export async function saveUserPreferences(prefs: UserPreferences): Promise<void> {
  const { data: existing } = await supabase
    .from('user_preferences')
    .select('id')
    .eq('user_session', 'default')
    .maybeSingle();

  if (existing) {
    await supabase
      .from('user_preferences')
      .update({ ...prefs, updated_at: new Date().toISOString() })
      .eq('user_session', 'default');
  } else {
    await supabase.from('user_preferences').insert(prefs);
  }
}

export async function deleteDetectionResult(id: string): Promise<void> {
  await supabase.from('detection_results').delete().eq('id', id);
}
