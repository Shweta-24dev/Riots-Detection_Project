import { useState } from 'react';
import Sidebar from './components/Layout/Sidebar';
import AnalysisPage from './pages/AnalysisPage';
import DashboardPage from './pages/DashboardPage';
import HistoryPage from './pages/HistoryPage';
import SettingsPage from './pages/SettingsPage';

type Page = 'analysis' | 'dashboard' | 'history' | 'settings';

export default function App() {
  const [page, setPage] = useState<Page>('analysis');

  const PAGE_MAP: Record<Page, React.ReactElement> = {
    analysis: <AnalysisPage />,
    dashboard: <DashboardPage />,
    history: <HistoryPage />,
    settings: <SettingsPage />,
  };

  return (
    <div className="flex h-screen overflow-hidden" style={{ backgroundColor: '#121212' }}>
      <Sidebar currentPage={page} onNavigate={setPage} />
      <main className="flex-1 overflow-hidden flex flex-col">
        {PAGE_MAP[page]}
      </main>
    </div>
  );
}
