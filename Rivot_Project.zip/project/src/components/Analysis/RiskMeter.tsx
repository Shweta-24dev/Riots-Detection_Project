import type { RiskLevel } from '../../types';

interface RiskMeterProps {
  score: number;
  level: RiskLevel;
  size?: 'sm' | 'md' | 'lg';
}

const LEVEL_CONFIG: Record<RiskLevel, { color: string; bg: string; label: string; glow: string }> = {
  safe: { color: '#22C55E', bg: '#22C55E15', label: 'SAFE', glow: '#22C55E40' },
  low: { color: '#84CC16', bg: '#84CC1615', label: 'LOW RISK', glow: '#84CC1640' },
  moderate: { color: '#F59E0B', bg: '#F59E0B15', label: 'MODERATE', glow: '#F59E0B40' },
  high: { color: '#F97316', bg: '#F9731615', label: 'HIGH RISK', glow: '#F9731640' },
  critical: { color: '#EF4444', bg: '#EF444415', label: 'CRITICAL', glow: '#EF444440' },
};

export default function RiskMeter({ score, level, size = 'md' }: RiskMeterProps) {
  const config = LEVEL_CONFIG[level];
  const dimensions = size === 'lg' ? 180 : size === 'md' ? 140 : 100;
  const strokeWidth = size === 'lg' ? 12 : size === 'md' ? 10 : 8;
  const radius = (dimensions - strokeWidth * 2) / 2;
  const circumference = 2 * Math.PI * radius;
  const progress = (score / 100) * circumference;
  const cx = dimensions / 2;
  const cy = dimensions / 2;

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative" style={{ width: dimensions, height: dimensions }}>
        <svg width={dimensions} height={dimensions} className="transform -rotate-90">
          <circle
            cx={cx}
            cy={cy}
            r={radius}
            fill="none"
            stroke="#1E2A3A"
            strokeWidth={strokeWidth}
          />
          <circle
            cx={cx}
            cy={cy}
            r={radius}
            fill="none"
            stroke={config.color}
            strokeWidth={strokeWidth}
            strokeDasharray={`${progress} ${circumference}`}
            strokeLinecap="round"
            style={{ filter: `drop-shadow(0 0 6px ${config.glow})`, transition: 'stroke-dasharray 1s ease' }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span
            className="font-bold leading-none"
            style={{
              color: config.color,
              fontSize: size === 'lg' ? '2.5rem' : size === 'md' ? '2rem' : '1.5rem',
            }}
          >
            {score}
          </span>
          <span className="text-xs mt-1" style={{ color: '#64748B' }}>%</span>
        </div>
      </div>
      <div
        className="px-4 py-1.5 rounded-full text-xs font-bold tracking-wider"
        style={{ backgroundColor: config.bg, color: config.color, border: `1px solid ${config.color}30` }}
      >
        {config.label}
      </div>
    </div>
  );
}
