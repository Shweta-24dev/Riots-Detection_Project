import type { AnalysisCategory } from '../../types';

interface CategoryBreakdownProps {
  categories: AnalysisCategory[];
}

const CATEGORY_COLORS: Record<string, string> = {
  'Riot Provocation': '#EF4444',
  'Violence & Physical Harm': '#F97316',
  'Hate Speech': '#DC2626',
  'Threats & Intimidation': '#F59E0B',
  'Extremist Content': '#EF4444',
  'Harassment & Stalking': '#8B5CF6',
  'Misinformation & Propaganda': '#06B6D4',
  'Incitement to Action': '#F97316',
};

export default function CategoryBreakdown({ categories }: CategoryBreakdownProps) {
  if (categories.length === 0) {
    return (
      <div className="text-center py-6">
        <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3" style={{ backgroundColor: '#22C55E15' }}>
          <span className="text-2xl">✓</span>
        </div>
        <p className="text-sm font-medium" style={{ color: '#22C55E' }}>No harmful categories detected</p>
        <p className="text-xs mt-1" style={{ color: '#475569' }}>Content appears safe</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {categories.map((cat, i) => {
        const color = CATEGORY_COLORS[cat.name] || '#38BDF8';
        return (
          <div key={i}>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-medium" style={{ color: '#CBD5E1' }}>{cat.name}</span>
              <span className="text-xs font-bold" style={{ color }}>{cat.score}%</span>
            </div>
            <div className="w-full h-1.5 rounded-full" style={{ backgroundColor: '#1E2A3A' }}>
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{
                  width: `${cat.score}%`,
                  backgroundColor: color,
                  boxShadow: `0 0 6px ${color}60`,
                }}
              />
            </div>
            {cat.detected_terms.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-1.5">
                {cat.detected_terms.slice(0, 4).map((term, j) => (
                  <span
                    key={j}
                    className="text-xs px-2 py-0.5 rounded"
                    style={{ backgroundColor: `${color}15`, color, border: `1px solid ${color}30` }}
                  >
                    {term}
                  </span>
                ))}
                {cat.detected_terms.length > 4 && (
                  <span className="text-xs px-2 py-0.5 rounded" style={{ color: '#475569' }}>
                    +{cat.detected_terms.length - 4} more
                  </span>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
