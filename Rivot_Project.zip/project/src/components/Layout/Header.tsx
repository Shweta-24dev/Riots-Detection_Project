import { Bell, Search } from 'lucide-react';

interface HeaderProps {
  title: string;
  subtitle?: string;
}

export default function Header({ title, subtitle }: HeaderProps) {
  return (
    <header className="px-8 py-5 flex items-center justify-between border-b" style={{ backgroundColor: '#121212', borderColor: '#1E2A3A' }}>
      <div>
        <h2 className="text-xl font-semibold text-white">{title}</h2>
        {subtitle && <p className="text-sm mt-0.5" style={{ color: '#64748B' }}>{subtitle}</p>}
      </div>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg" style={{ backgroundColor: '#1A2332', border: '1px solid #1E2A3A' }}>
          <Search size={14} style={{ color: '#64748B' }} />
          <span className="text-xs" style={{ color: '#475569' }}>Quick search...</span>
          <kbd className="text-xs px-1.5 py-0.5 rounded" style={{ backgroundColor: '#0F172A', color: '#475569', border: '1px solid #1E2A3A' }}>⌘K</kbd>
        </div>
        <button className="relative w-9 h-9 rounded-lg flex items-center justify-center transition-colors" style={{ backgroundColor: '#1A2332', border: '1px solid #1E2A3A' }}>
          <Bell size={16} style={{ color: '#94A3B8' }} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full" style={{ backgroundColor: '#EF4444' }} />
        </button>
      </div>
    </header>
  );
}
