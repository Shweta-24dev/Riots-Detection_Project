import { Shield, LayoutDashboard, History, Settings, ChevronRight, AlertTriangle } from 'lucide-react';

type Page = 'analysis' | 'dashboard' | 'history' | 'settings';

interface SidebarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

const NAV_ITEMS = [
  { id: 'analysis' as Page, label: 'Content Analysis', icon: Shield, desc: 'Scan & detect' },
  { id: 'dashboard' as Page, label: 'Admin Dashboard', icon: LayoutDashboard, desc: 'Overview & stats' },
  { id: 'history' as Page, label: 'Detection History', icon: History, desc: 'Past results' },
  { id: 'settings' as Page, label: 'Preferences', icon: Settings, desc: 'Content settings' },
];

export default function Sidebar({ currentPage, onNavigate }: SidebarProps) {
  return (
    <aside className="w-64 min-h-screen flex flex-col" style={{ backgroundColor: '#0A0A0A', borderRight: '1px solid #1E2A3A' }}>
      <div className="p-6 border-b" style={{ borderColor: '#1E2A3A' }}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #0EA5E9, #0284C7)' }}>
            <AlertTriangle size={20} className="text-white" />
          </div>
          <div>
            <h1 className="font-bold text-white text-sm leading-tight">RiotGuard AI</h1>
            <p className="text-xs mt-0.5" style={{ color: '#64748B' }}>Content Safety System</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {NAV_ITEMS.map(({ id, label, icon: Icon, desc }) => {
          const active = currentPage === id;
          return (
            <button
              key={id}
              onClick={() => onNavigate(id)}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200 group text-left"
              style={{
                backgroundColor: active ? '#0EA5E915' : 'transparent',
                border: active ? '1px solid #0EA5E930' : '1px solid transparent',
              }}
            >
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 transition-all"
                style={{ backgroundColor: active ? '#0EA5E920' : '#1A2332' }}
              >
                <Icon size={16} style={{ color: active ? '#38BDF8' : '#64748B' }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate" style={{ color: active ? '#F0F9FF' : '#94A3B8' }}>
                  {label}
                </p>
                <p className="text-xs truncate" style={{ color: '#475569' }}>{desc}</p>
              </div>
              {active && <ChevronRight size={14} style={{ color: '#38BDF8' }} />}
            </button>
          );
        })}
      </nav>

      <div className="p-4 m-4 rounded-xl" style={{ backgroundColor: '#0EA5E910', border: '1px solid #0EA5E920' }}>
        <div className="flex items-center gap-2 mb-2">
          <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: '#22C55E' }} />
          <span className="text-xs font-medium" style={{ color: '#94A3B8' }}>AI Engine Active</span>
        </div>
        <p className="text-xs" style={{ color: '#475569' }}>Real-time content monitoring enabled</p>
      </div>
    </aside>
  );
}
