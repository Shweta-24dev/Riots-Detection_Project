import type { LucideIcon } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  iconColor: string;
  trend?: { value: number; positive: boolean };
}

export default function StatsCard({ title, value, subtitle, icon: Icon, iconColor, trend }: StatsCardProps) {
  return (
    <div
      className="rounded-2xl p-5 flex flex-col gap-4 transition-all duration-200 hover:translate-y-[-2px]"
      style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}
    >
      <div className="flex items-start justify-between">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ backgroundColor: `${iconColor}15` }}
        >
          <Icon size={18} style={{ color: iconColor }} />
        </div>
        {trend && (
          <span
            className="text-xs font-medium px-2 py-1 rounded-lg"
            style={{
              backgroundColor: trend.positive ? '#22C55E15' : '#EF444415',
              color: trend.positive ? '#22C55E' : '#EF4444',
            }}
          >
            {trend.positive ? '+' : ''}{trend.value}%
          </span>
        )}
      </div>
      <div>
        <p className="text-2xl font-bold text-white">{value}</p>
        <p className="text-sm font-medium mt-0.5" style={{ color: '#64748B' }}>{title}</p>
        {subtitle && <p className="text-xs mt-1" style={{ color: '#475569' }}>{subtitle}</p>}
      </div>
    </div>
  );
}
