interface DistributionItem {
  label: string;
  count: number;
  color: string;
}

interface RiskDistributionProps {
  data: DistributionItem[];
  total: number;
}

export default function RiskDistribution({ data, total }: RiskDistributionProps) {
  return (
    <div className="rounded-2xl p-6" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
      <h3 className="text-sm font-semibold text-white mb-4">Risk Distribution</h3>
      <div className="space-y-3">
        {data.map(({ label, count, color }) => {
          const pct = total > 0 ? Math.round((count / total) * 100) : 0;
          return (
            <div key={label}>
              <div className="flex justify-between items-center mb-1">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
                  <span className="text-xs" style={{ color: '#94A3B8' }}>{label}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium text-white">{count}</span>
                  <span className="text-xs" style={{ color: '#475569' }}>({pct}%)</span>
                </div>
              </div>
              <div className="w-full h-1.5 rounded-full" style={{ backgroundColor: '#1E2A3A' }}>
                <div
                  className="h-full rounded-full transition-all duration-700"
                  style={{ width: `${pct}%`, backgroundColor: color }}
                />
              </div>
            </div>
          );
        })}
      </div>
      {total === 0 && (
        <p className="text-xs text-center py-4" style={{ color: '#475569' }}>No data yet. Start scanning content.</p>
      )}
    </div>
  );
}
