export type RiskLevel = 'safe' | 'low' | 'moderate' | 'high' | 'critical';
export type ContentType = 'text' | 'url' | 'caption' | 'email' | 'message';

export interface AnalysisCategory {
  name: string;
  score: number;
  detected_terms: string[];
  weight: number;
}

export interface DetectionResult {
  id?: string;
  content_type: ContentType;
  input_content: string;
  source_url?: string;
  risk_score: number;
  risk_level: RiskLevel;
  categories: AnalysisCategory[];
  summary: string;
  keywords_detected: string[];
  is_flagged: boolean;
  word_count: number;
  recommendation?: string;
  created_at?: string;
}

export interface UserPreferences {
  id?: string;
  user_session: string;
  allowed_categories: string[];
  alert_threshold: number;
  blocked_keywords: string[];
  content_filters: Record<string, boolean>;
  website_whitelist: string[];
  website_blacklist: string[];
  notifications_enabled: boolean;
}

export interface WebsiteScan {
  id?: string;
  url: string;
  domain: string;
  overall_risk_score: number;
  risk_level: RiskLevel;
  pages_scanned: number;
  status: string;
  scan_results: Record<string, unknown>;
  is_recommended: boolean;
  created_at?: string;
}

export interface DashboardStats {
  total_scans: number;
  flagged_content: number;
  safe_content: number;
  avg_risk_score: number;
  critical_alerts: number;
  websites_scanned: number;
}
