import { useEffect, useState } from 'react';
import { History, Search, Trash2, ChevronDown, ChevronUp, Filter } from 'lucide-react';
import Header from '../components/Layout/Header';
import RiskMeter from '../components/Analysis/RiskMeter';
import CategoryBreakdown from '../components/Analysis/CategoryBreakdown';
import { fetchDetectionHistory, deleteDetectionResult } from '../lib/analysisService';
import type { DetectionResult, RiskLevel } from '../types';

const RISK_COLORS: Record<string, string> = {
  safe: '#22C55E', low: '#84CC16', moderate: '#F59E0B', high: '#F97316', critical: '#EF4444',
};

const LEVEL_FILTERS: { value: string; label: string }[] = [
  { value: 'all', label: 'All Results' },
  { value: 'critical', label: 'Critical' },
  { value: 'high', label: 'High Risk' },
  { value: 'moderate', label: 'Moderate' },
  { value: 'low', label: 'Low Risk' },
  { value: 'safe', label: 'Safe' },
];

export default function HistoryPage() {
  const [results, setResults] = useState<(DetectionResult & { id: string; created_at: string })[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [showFilter, setShowFilter] = useState(false);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    setLoading(true);
    try {
      const data = await fetchDetectionHistory(100);
      setResults(data as unknown as (DetectionResult & { id: string; created_at: string })[]);
    } finally {
      setLoading(false);
    }
  }

  async function handleDelete(id: string) {
    await deleteDetectionResult(id);
    setResults(prev => prev.filter(r => r.id !== id));
  }

  const filtered = results.filter(r => {
    const matchLevel = filter === 'all' || r.risk_level === filter;
    const matchSearch = !search || r.input_content.toLowerCase().includes(search.toLowerCase());
    return matchLevel && matchSearch;
  });

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: '#121212' }}>
      <Header title="Detection History" subtitle="All past content analysis results" />

      <div className="flex-1 overflow-y-auto p-8">
        <div className="max-w-5xl mx-auto space-y-4">

          <div className="flex items-center gap-3">
            <div className="flex-1 flex items-center gap-2 px-4 py-2.5 rounded-xl" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
              <Search size={14} style={{ color: '#64748B' }} />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search detection history..."
                className="flex-1 bg-transparent outline-none text-sm"
                style={{ color: '#E2E8F0', caretColor: '#38BDF8' }}
              />
            </div>
            <div className="relative">
              <button
                onClick={() => setShowFilter(!showFilter)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm transition-colors"
                style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A', color: '#94A3B8' }}
              >
                <Filter size={14} />
                {LEVEL_FILTERS.find(f => f.value === filter)?.label}
                <ChevronDown size={12} />
              </button>
              {showFilter && (
                <div className="absolute right-0 top-12 z-10 w-40 rounded-xl py-1 shadow-2xl" style={{ backgroundColor: '#1A2332', border: '1px solid #1E2A3A' }}>
                  {LEVEL_FILTERS.map(f => (
                    <button
                      key={f.value}
                      onClick={() => { setFilter(f.value); setShowFilter(false); }}
                      className="w-full text-left px-3 py-2 text-xs transition-colors hover:bg-white/5"
                      style={{ color: filter === f.value ? '#38BDF8' : '#94A3B8' }}
                    >
                      {f.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <p className="text-xs" style={{ color: '#475569' }}>{filtered.length} results found</p>
            <div className="flex items-center gap-2">
              <History size={12} style={{ color: '#475569' }} />
              <p className="text-xs" style={{ color: '#475569' }}>Showing latest first</p>
            </div>
          </div>

          {loading ? (
            <div className="text-center py-20">
              <div className="w-8 h-8 border-2 rounded-full animate-spin mx-auto" style={{ borderColor: '#0EA5E9', borderTopColor: 'transparent' }} />
              <p className="text-sm mt-3" style={{ color: '#64748B' }}>Loading history...</p>
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-20">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
                <History size={28} style={{ color: '#475569' }} />
              </div>
              <p className="text-white font-medium">No results found</p>
              <p className="text-sm mt-1" style={{ color: '#475569' }}>Try adjusting your search or filter.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filtered.map(item => {
                const isOpen = expanded === item.id;
                const color = RISK_COLORS[item.risk_level];
                return (
                  <div key={item.id} className="rounded-2xl overflow-hidden transition-all" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
                    <div
                      className="flex items-center gap-4 p-4 cursor-pointer"
                      onClick={() => setExpanded(isOpen ? null : item.id)}
                    >
                      <div className="flex-shrink-0">
                        <RiskMeter score={item.risk_score} level={item.risk_level as RiskLevel} size="sm" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-white font-medium truncate">{item.input_content?.slice(0, 80)}</p>
                        <div className="flex items-center gap-3 mt-1">
                          <span className="text-xs capitalize px-2 py-0.5 rounded" style={{ backgroundColor: '#1E2A3A', color: '#64748B' }}>{item.content_type}</span>
                          <span className="text-xs" style={{ color: '#475569' }}>{new Date(item.created_at).toLocaleString()}</span>
                          {item.is_flagged && (
                            <span className="text-xs px-2 py-0.5 rounded" style={{ backgroundColor: '#EF444415', color: '#EF4444' }}>Flagged</span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-3 flex-shrink-0">
                        <span className="text-sm font-bold" style={{ color }}>{item.risk_score}%</span>
                        <button
                          onClick={e => { e.stopPropagation(); handleDelete(item.id); }}
                          className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors hover:bg-red-500/10"
                          style={{ color: '#475569' }}
                        >
                          <Trash2 size={13} />
                        </button>
                        {isOpen ? <ChevronUp size={14} style={{ color: '#64748B' }} /> : <ChevronDown size={14} style={{ color: '#64748B' }} />}
                      </div>
                    </div>

                    {isOpen && (
                      <div className="px-4 pb-4 pt-2 space-y-4" style={{ borderTop: '1px solid #1E2A3A' }}>
                        <div className="p-3 rounded-xl" style={{ backgroundColor: '#1A2332' }}>
                          <p className="text-xs font-semibold mb-1" style={{ color: '#64748B' }}>SUMMARY</p>
                          <p className="text-xs leading-relaxed" style={{ color: '#CBD5E1' }}>{item.summary}</p>
                        </div>
                        <div>
                          <p className="text-xs font-semibold mb-3" style={{ color: '#64748B' }}>CATEGORY BREAKDOWN</p>
                          <CategoryBreakdown categories={item.categories || []} />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
