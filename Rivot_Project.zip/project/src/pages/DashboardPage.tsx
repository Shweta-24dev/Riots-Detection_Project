import { useEffect, useState } from 'react';
import { Shield, AlertTriangle, CheckCircle, BarChart2, Globe, TrendingUp, Clock, Flag } from 'lucide-react';
import Header from '../components/Layout/Header';
import StatsCard from '../components/Dashboard/StatsCard';
import RiskDistribution from '../components/Dashboard/RiskDistribution';
import { fetchDashboardStats, fetchDetectionHistory } from '../lib/analysisService';
import type { DashboardStats, DetectionResult } from '../types';

const RISK_COLORS: Record<string, string> = {
  safe: '#22C55E',
  low: '#84CC16',
  moderate: '#F59E0B',
  high: '#F97316',
  critical: '#EF4444',
};

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recent, setRecent] = useState<DetectionResult[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [s, h] = await Promise.all([fetchDashboardStats(), fetchDetectionHistory(5)]);
        setStats(s);
        setRecent(h as unknown as DetectionResult[]);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const distributionData = stats
    ? [
        { label: 'Safe', count: stats.safe_content, color: '#22C55E' },
        { label: 'Low Risk', count: stats.total_scans - stats.flagged_content - stats.safe_content, color: '#84CC16' },
        { label: 'Flagged', count: stats.flagged_content, color: '#F97316' },
        { label: 'Critical', count: stats.critical_alerts, color: '#EF4444' },
      ]
    : [];

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: '#121212' }}>
      <Header title="Admin Dashboard" subtitle="System overview and detection analytics" />

      <div className="flex-1 overflow-y-auto p-8">
        <div className="max-w-6xl mx-auto space-y-6">

          {loading ? (
            <div className="text-center py-20">
              <div className="w-8 h-8 border-2 border-t-transparent rounded-full animate-spin mx-auto" style={{ borderColor: '#0EA5E9', borderTopColor: 'transparent' }} />
              <p className="text-sm mt-3" style={{ color: '#64748B' }}>Loading analytics...</p>
            </div>
          ) : stats ? (
            <>
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
                <StatsCard title="Total Scans" value={stats.total_scans} subtitle="All time" icon={Shield} iconColor="#38BDF8" />
                <StatsCard title="Flagged Content" value={stats.flagged_content} subtitle="High risk or above" icon={Flag} iconColor="#F97316" />
                <StatsCard title="Safe Content" value={stats.safe_content} subtitle="Cleared by AI" icon={CheckCircle} iconColor="#22C55E" />
                <StatsCard title="Avg Risk Score" value={`${stats.avg_risk_score}%`} subtitle="Across all scans" icon={BarChart2} iconColor="#F59E0B" />
                <StatsCard title="Critical Alerts" value={stats.critical_alerts} subtitle="Immediate action needed" icon={AlertTriangle} iconColor="#EF4444" />
                <StatsCard title="Sites Scanned" value={stats.websites_scanned} subtitle="URLs analyzed" icon={Globe} iconColor="#8B5CF6" />
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <RiskDistribution data={distributionData} total={stats.total_scans} />

                <div className="rounded-2xl p-6" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
                  <div className="flex items-center gap-2 mb-4">
                    <TrendingUp size={14} style={{ color: '#38BDF8' }} />
                    <h3 className="text-sm font-semibold text-white">System Health</h3>
                  </div>
                  <div className="space-y-4">
                    {[
                      { label: 'AI Engine', value: 'Operational', color: '#22C55E', pct: 100 },
                      { label: 'Database', value: 'Connected', color: '#22C55E', pct: 100 },
                      { label: 'Detection Accuracy', value: '94.2%', color: '#38BDF8', pct: 94 },
                      { label: 'Response Time', value: '< 2s avg', color: '#84CC16', pct: 88 },
                    ].map(({ label, value, color, pct }) => (
                      <div key={label}>
                        <div className="flex justify-between text-xs mb-1">
                          <span style={{ color: '#94A3B8' }}>{label}</span>
                          <span style={{ color }}>{value}</span>
                        </div>
                        <div className="w-full h-1.5 rounded-full" style={{ backgroundColor: '#1E2A3A' }}>
                          <div className="h-full rounded-full" style={{ width: `${pct}%`, backgroundColor: color }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="rounded-2xl p-6" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
                <div className="flex items-center gap-2 mb-4">
                  <Clock size={14} style={{ color: '#38BDF8' }} />
                  <h3 className="text-sm font-semibold text-white">Recent Detections</h3>
                </div>
                {recent.length === 0 ? (
                  <p className="text-sm text-center py-8" style={{ color: '#475569' }}>No detections yet. Start by analyzing content.</p>
                ) : (
                  <div className="space-y-2">
                    {recent.map((item: DetectionResult & { id?: string; created_at?: string }, idx) => (
                      <div key={item.id || idx} className="flex items-center gap-4 p-3 rounded-xl" style={{ backgroundColor: '#1A2332' }}>
                        <div
                          className="w-2 h-2 rounded-full flex-shrink-0"
                          style={{ backgroundColor: RISK_COLORS[item.risk_level] }}
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-medium text-white truncate">
                            {item.input_content?.slice(0, 60)}...
                          </p>
                          <p className="text-xs mt-0.5" style={{ color: '#475569' }}>
                            {item.content_type} · {new Date(item.created_at || '').toLocaleString()}
                          </p>
                        </div>
                        <div className="flex items-center gap-3 flex-shrink-0">
                          <span className="text-xs font-bold" style={{ color: RISK_COLORS[item.risk_level] }}>
                            {item.risk_score}%
                          </span>
                          <span
                            className="text-xs px-2 py-0.5 rounded capitalize"
                            style={{
                              backgroundColor: `${RISK_COLORS[item.risk_level]}15`,
                              color: RISK_COLORS[item.risk_level],
                            }}
                          >
                            {item.risk_level}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          ) : (
            <p className="text-center" style={{ color: '#64748B' }}>Failed to load dashboard data.</p>
          )}
        </div>
      </div>
    </div>
  );
}
