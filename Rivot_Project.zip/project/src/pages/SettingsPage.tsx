import { useEffect, useState } from 'react';
import { Settings, Shield, Bell, Globe, Tag, Save, CheckCircle, Plus, X, Sparkles } from 'lucide-react';
import Header from '../components/Layout/Header';
import { getUserPreferences, saveUserPreferences } from '../lib/analysisService';
import type { UserPreferences } from '../types';

const CONTENT_CATEGORIES = [
  { id: 'news', label: 'News & Media', desc: 'Journalism, reporting, current events' },
  { id: 'education', label: 'Education', desc: 'Academic content, tutorials, learning' },
  { id: 'social', label: 'Social Media', desc: 'Posts, comments, discussions' },
  { id: 'entertainment', label: 'Entertainment', desc: 'Movies, music, games, humor' },
  { id: 'politics', label: 'Political Content', desc: 'Government, policy, civic discourse' },
  { id: 'religion', label: 'Religious Content', desc: 'Faith-based, spiritual discussions' },
  { id: 'activism', label: 'Activism', desc: 'Civil rights, advocacy, campaigns' },
  { id: 'sports', label: 'Sports', desc: 'Athletics, competitions, fan content' },
];

const FILTER_LABELS: Record<string, { label: string; desc: string; color: string }> = {
  violence: { label: 'Violence Detection', desc: 'Detect physical harm and assault content', color: '#F97316' },
  hate_speech: { label: 'Hate Speech', desc: 'Identify discrimination and slurs', color: '#EF4444' },
  riot_provocation: { label: 'Riot Provocation', desc: 'Flag content inciting civil unrest', color: '#DC2626' },
  threats: { label: 'Threats & Intimidation', desc: 'Detect threatening language', color: '#F59E0B' },
  extremism: { label: 'Extremist Content', desc: 'Identify radical ideology content', color: '#EF4444' },
  harassment: { label: 'Harassment Detection', desc: 'Flag bullying and stalking content', color: '#8B5CF6' },
  misinformation: { label: 'Misinformation', desc: 'Detect propaganda and fake news', color: '#06B6D4' },
};

const SUGGESTED_SITES = [
  { url: 'reuters.com', label: 'Reuters', category: 'Trusted News', score: 8 },
  { url: 'bbc.com', label: 'BBC News', category: 'Trusted News', score: 9 },
  { url: 'apnews.com', label: 'AP News', category: 'Trusted News', score: 9 },
  { url: 'scholar.google.com', label: 'Google Scholar', category: 'Education', score: 10 },
  { url: 'wikipedia.org', label: 'Wikipedia', category: 'Reference', score: 8 },
];

export default function SettingsPage() {
  const [prefs, setPrefs] = useState<UserPreferences | null>(null);
  const [saved, setSaved] = useState(false);
  const [newKeyword, setNewKeyword] = useState('');
  const [newWhitesite, setNewWhitesite] = useState('');

  useEffect(() => {
    getUserPreferences().then(setPrefs);
  }, []);

  async function handleSave() {
    if (!prefs) return;
    await saveUserPreferences(prefs);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  }

  function toggleCategory(id: string) {
    if (!prefs) return;
    const current = prefs.allowed_categories || [];
    const updated = current.includes(id) ? current.filter(c => c !== id) : [...current, id];
    setPrefs({ ...prefs, allowed_categories: updated });
  }

  function toggleFilter(key: string) {
    if (!prefs) return;
    setPrefs({ ...prefs, content_filters: { ...prefs.content_filters, [key]: !prefs.content_filters[key] } });
  }

  function addKeyword() {
    if (!prefs || !newKeyword.trim()) return;
    const updated = [...(prefs.blocked_keywords || []), newKeyword.trim()];
    setPrefs({ ...prefs, blocked_keywords: updated });
    setNewKeyword('');
  }

  function removeKeyword(kw: string) {
    if (!prefs) return;
    setPrefs({ ...prefs, blocked_keywords: prefs.blocked_keywords.filter(k => k !== kw) });
  }

  function addWhitesite() {
    if (!prefs || !newWhitesite.trim()) return;
    const updated = [...(prefs.website_whitelist || []), newWhitesite.trim()];
    setPrefs({ ...prefs, website_whitelist: updated });
    setNewWhitesite('');
  }

  if (!prefs) {
    return (
      <div className="flex flex-col h-full" style={{ backgroundColor: '#121212' }}>
        <Header title="Preferences" subtitle="Configure your content filters and alerts" />
        <div className="flex-1 flex items-center justify-center">
          <div className="w-8 h-8 border-2 rounded-full animate-spin" style={{ borderColor: '#0EA5E9', borderTopColor: 'transparent' }} />
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: '#121212' }}>
      <Header title="Preferences" subtitle="Configure your content filters and alerts" />

      <div className="flex-1 overflow-y-auto p-8">
        <div className="max-w-4xl mx-auto space-y-6">

          <div className="rounded-2xl p-6" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
            <div className="flex items-center gap-2 mb-1">
              <Shield size={15} style={{ color: '#38BDF8' }} />
              <h3 className="text-sm font-semibold text-white">Detection Filters</h3>
            </div>
            <p className="text-xs mb-5" style={{ color: '#475569' }}>Choose which types of harmful content the AI should actively detect and flag.</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {Object.entries(FILTER_LABELS).map(([key, info]) => {
                const enabled = prefs.content_filters[key];
                return (
                  <div
                    key={key}
                    onClick={() => toggleFilter(key)}
                    className="flex items-start gap-3 p-4 rounded-xl cursor-pointer transition-all"
                    style={{
                      backgroundColor: enabled ? `${info.color}10` : '#1A2332',
                      border: `1px solid ${enabled ? `${info.color}30` : '#1E2A3A'}`,
                    }}
                  >
                    <div
                      className="w-5 h-5 rounded flex items-center justify-center flex-shrink-0 mt-0.5 transition-all"
                      style={{ backgroundColor: enabled ? info.color : '#1E2A3A', border: `2px solid ${enabled ? info.color : '#2A3A4A'}` }}
                    >
                      {enabled && <CheckCircle size={12} className="text-white" />}
                    </div>
                    <div>
                      <p className="text-xs font-medium" style={{ color: enabled ? '#F0F9FF' : '#94A3B8' }}>{info.label}</p>
                      <p className="text-xs mt-0.5" style={{ color: '#475569' }}>{info.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="rounded-2xl p-6" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
            <div className="flex items-center gap-2 mb-1">
              <Bell size={15} style={{ color: '#38BDF8' }} />
              <h3 className="text-sm font-semibold text-white">Alert Threshold</h3>
            </div>
            <p className="text-xs mb-5" style={{ color: '#475569' }}>Set the minimum risk score percentage that triggers an alert notification.</p>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs" style={{ color: '#94A3B8' }}>Alert when risk score exceeds:</span>
                <span className="text-lg font-bold" style={{ color: '#38BDF8' }}>{prefs.alert_threshold}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={prefs.alert_threshold}
                onChange={e => setPrefs({ ...prefs, alert_threshold: Number(e.target.value) })}
                className="w-full accent-sky-500"
                style={{ accentColor: '#0EA5E9' }}
              />
              <div className="flex justify-between text-xs" style={{ color: '#475569' }}>
                <span>0% (All)</span>
                <span>50% (Moderate+)</span>
                <span>100% (Critical only)</span>
              </div>
            </div>
            <div className="flex items-center justify-between mt-4 p-3 rounded-xl" style={{ backgroundColor: '#1A2332' }}>
              <div>
                <p className="text-xs font-medium text-white">Enable Notifications</p>
                <p className="text-xs mt-0.5" style={{ color: '#475569' }}>Get alerted when content exceeds your threshold</p>
              </div>
              <button
                onClick={() => setPrefs({ ...prefs, notifications_enabled: !prefs.notifications_enabled })}
                className="w-12 h-6 rounded-full transition-all relative"
                style={{ backgroundColor: prefs.notifications_enabled ? '#0EA5E9' : '#1E2A3A' }}
              >
                <div
                  className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all"
                  style={{ left: prefs.notifications_enabled ? 'calc(100% - 22px)' : '2px' }}
                />
              </button>
            </div>
          </div>

          <div className="rounded-2xl p-6" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
            <div className="flex items-center gap-2 mb-1">
              <Tag size={15} style={{ color: '#38BDF8' }} />
              <h3 className="text-sm font-semibold text-white">Content Preferences</h3>
            </div>
            <p className="text-xs mb-5" style={{ color: '#475569' }}>Select the content categories you want to see. The AI will suggest suitable platforms based on your choices.</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {CONTENT_CATEGORIES.map(cat => {
                const active = prefs.allowed_categories.includes(cat.id);
                return (
                  <div
                    key={cat.id}
                    onClick={() => toggleCategory(cat.id)}
                    className="p-3 rounded-xl cursor-pointer transition-all text-center"
                    style={{
                      backgroundColor: active ? '#0EA5E910' : '#1A2332',
                      border: `1px solid ${active ? '#0EA5E930' : '#1E2A3A'}`,
                    }}
                  >
                    <p className="text-xs font-medium" style={{ color: active ? '#38BDF8' : '#94A3B8' }}>{cat.label}</p>
                    <p className="text-xs mt-0.5" style={{ color: '#475569' }}>{cat.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="rounded-2xl p-6" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
            <div className="flex items-center gap-2 mb-1">
              <Sparkles size={15} style={{ color: '#38BDF8' }} />
              <h3 className="text-sm font-semibold text-white">AI Website Recommendations</h3>
            </div>
            <p className="text-xs mb-4" style={{ color: '#475569' }}>
              Based on your content preferences ({prefs.allowed_categories.join(', ')}), these platforms are recommended for safe browsing.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
              {SUGGESTED_SITES.filter(s =>
                prefs.allowed_categories.some(c => s.category.toLowerCase().includes(c)) || prefs.allowed_categories.length > 2
              ).slice(0, 4).map(site => (
                <div key={site.url} className="flex items-center gap-3 p-3 rounded-xl" style={{ backgroundColor: '#1A2332', border: '1px solid #1E2A3A' }}>
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#22C55E15' }}>
                    <Globe size={14} style={{ color: '#22C55E' }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-white">{site.label}</p>
                    <p className="text-xs" style={{ color: '#475569' }}>{site.category}</p>
                  </div>
                  <div className="text-xs font-bold" style={{ color: '#22C55E' }}>{site.score}/10</div>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                value={newWhitesite}
                onChange={e => setNewWhitesite(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addWhitesite()}
                placeholder="Add trusted website (e.g. example.com)"
                className="flex-1 px-3 py-2 rounded-lg text-xs bg-transparent outline-none"
                style={{ border: '1px solid #1E2A3A', color: '#E2E8F0', caretColor: '#38BDF8' }}
              />
              <button
                onClick={addWhitesite}
                className="px-3 py-2 rounded-lg flex items-center gap-1 text-xs font-medium transition-colors"
                style={{ backgroundColor: '#0EA5E920', color: '#38BDF8', border: '1px solid #0EA5E930' }}
              >
                <Plus size={12} /> Add
              </button>
            </div>
            {prefs.website_whitelist.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {prefs.website_whitelist.map(site => (
                  <div key={site} className="flex items-center gap-1.5 px-2 py-1 rounded text-xs" style={{ backgroundColor: '#22C55E15', color: '#22C55E', border: '1px solid #22C55E30' }}>
                    {site}
                    <button onClick={() => setPrefs({ ...prefs, website_whitelist: prefs.website_whitelist.filter(s => s !== site) })}><X size={10} /></button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="rounded-2xl p-6" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
            <div className="flex items-center gap-2 mb-1">
              <Settings size={15} style={{ color: '#38BDF8' }} />
              <h3 className="text-sm font-semibold text-white">Custom Blocked Keywords</h3>
            </div>
            <p className="text-xs mb-4" style={{ color: '#475569' }}>Add specific words or phrases you want the AI to flag automatically.</p>
            <div className="flex gap-2 mb-3">
              <input
                value={newKeyword}
                onChange={e => setNewKeyword(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addKeyword()}
                placeholder="Type a keyword and press Enter..."
                className="flex-1 px-3 py-2 rounded-lg text-xs bg-transparent outline-none"
                style={{ border: '1px solid #1E2A3A', color: '#E2E8F0', caretColor: '#38BDF8' }}
              />
              <button
                onClick={addKeyword}
                className="px-3 py-2 rounded-lg flex items-center gap-1 text-xs font-medium"
                style={{ backgroundColor: '#0EA5E920', color: '#38BDF8', border: '1px solid #0EA5E930' }}
              >
                <Plus size={12} /> Add
              </button>
            </div>
            {prefs.blocked_keywords.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {prefs.blocked_keywords.map(kw => (
                  <div key={kw} className="flex items-center gap-1.5 px-2 py-1 rounded text-xs" style={{ backgroundColor: '#EF444415', color: '#EF4444', border: '1px solid #EF444430' }}>
                    {kw}
                    <button onClick={() => removeKeyword(kw)}><X size={10} /></button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs" style={{ color: '#475569' }}>No custom keywords added yet.</p>
            )}
          </div>

          <div className="flex justify-end">
            <button
              onClick={handleSave}
              className="flex items-center gap-2 px-6 py-3 rounded-xl font-semibold text-sm transition-all duration-200"
              style={{ background: 'linear-gradient(135deg, #0EA5E9, #0284C7)', color: 'white', boxShadow: '0 0 20px #0EA5E930' }}
            >
              {saved ? <CheckCircle size={16} /> : <Save size={16} />}
              {saved ? 'Preferences Saved!' : 'Save Preferences'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
