import { useState } from 'react';
import { Shield, Link, FileText, MessageSquare, Mail, Video, Loader2, AlertTriangle, CheckCircle, Info, ChevronDown } from 'lucide-react';
import RiskMeter from '../components/Analysis/RiskMeter';
import CategoryBreakdown from '../components/Analysis/CategoryBreakdown';
import { analyzeContent } from '../lib/analysisService';
import type { ContentType, DetectionResult } from '../types';
import Header from '../components/Layout/Header';

const CONTENT_TYPES: { id: ContentType; label: string; icon: React.ElementType; placeholder: string }[] = [
  { id: 'text', label: 'Text / Post', icon: FileText, placeholder: 'Paste any text, social media post, or article content here...' },
  { id: 'url', label: 'Website URL', icon: Link, placeholder: 'https://example.com — Enter a website URL to scan its content...' },
  { id: 'caption', label: 'Video Caption', icon: Video, placeholder: 'Paste video captions or subtitles for analysis...' },
  { id: 'message', label: 'Message / Chat', icon: MessageSquare, placeholder: 'Paste chat messages, DMs, or group messages here...' },
  { id: 'email', label: 'Email Content', icon: Mail, placeholder: 'Paste the email subject and body content for analysis...' },
];

const LEVEL_STYLES = {
  safe: { bg: '#22C55E10', border: '#22C55E30', icon: CheckCircle, iconColor: '#22C55E' },
  low: { bg: '#84CC1610', border: '#84CC1630', icon: Info, iconColor: '#84CC16' },
  moderate: { bg: '#F59E0B10', border: '#F59E0B30', icon: AlertTriangle, iconColor: '#F59E0B' },
  high: { bg: '#F9731610', border: '#F9731630', icon: AlertTriangle, iconColor: '#F97316' },
  critical: { bg: '#EF444410', border: '#EF444430', icon: AlertTriangle, iconColor: '#EF4444' },
};

export default function AnalysisPage() {
  const [contentType, setContentType] = useState<ContentType>('text');
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DetectionResult | null>(null);
  const [error, setError] = useState('');
  const [showTypeDropdown, setShowTypeDropdown] = useState(false);

  const selectedType = CONTENT_TYPES.find(t => t.id === contentType)!;

  async function handleAnalyze() {
    if (!inputValue.trim()) return;
    setLoading(true);
    setError('');
    setResult(null);
    try {
      const isUrl = contentType === 'url';
      const res = await analyzeContent(
        isUrl ? '' : inputValue,
        contentType,
        isUrl ? inputValue : undefined
      );
      setResult(res);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Analysis failed. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  const levelStyle = result ? LEVEL_STYLES[result.risk_level] : null;
  const LevelIcon = levelStyle?.icon;

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: '#121212' }}>
      <Header title="Content Analysis" subtitle="AI-powered harmful content detection" />

      <div className="flex-1 overflow-y-auto p-8">
        <div className="max-w-5xl mx-auto space-y-6">

          <div className="rounded-2xl p-6" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-white">Input Content</h3>
              <div className="relative">
                <button
                  onClick={() => setShowTypeDropdown(!showTypeDropdown)}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-colors"
                  style={{ backgroundColor: '#1E2A3A', color: '#94A3B8', border: '1px solid #2A3A4A' }}
                >
                  <selectedType.icon size={13} />
                  {selectedType.label}
                  <ChevronDown size={12} />
                </button>
                {showTypeDropdown && (
                  <div
                    className="absolute right-0 top-10 z-10 w-48 rounded-xl py-1 shadow-2xl"
                    style={{ backgroundColor: '#1A2332', border: '1px solid #1E2A3A' }}
                  >
                    {CONTENT_TYPES.map(type => (
                      <button
                        key={type.id}
                        onClick={() => { setContentType(type.id); setShowTypeDropdown(false); }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs transition-colors hover:bg-white/5"
                        style={{ color: contentType === type.id ? '#38BDF8' : '#94A3B8' }}
                      >
                        <type.icon size={13} />
                        {type.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <textarea
              value={inputValue}
              onChange={e => setInputValue(e.target.value)}
              placeholder={selectedType.placeholder}
              rows={contentType === 'url' ? 2 : 7}
              className="w-full bg-transparent resize-none outline-none text-sm leading-relaxed"
              style={{ color: '#E2E8F0', caretColor: '#38BDF8' }}
            />

            <div className="flex items-center justify-between mt-4 pt-4" style={{ borderTop: '1px solid #1E2A3A' }}>
              <div className="flex items-center gap-4">
                <span className="text-xs" style={{ color: '#475569' }}>
                  {inputValue.trim().split(/\s+/).filter(Boolean).length} words
                </span>
                {contentType === 'url' && (
                  <span className="text-xs px-2 py-0.5 rounded" style={{ backgroundColor: '#0EA5E915', color: '#38BDF8' }}>
                    Will scan full webpage content
                  </span>
                )}
              </div>
              <button
                onClick={handleAnalyze}
                disabled={loading || !inputValue.trim()}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
                style={{
                  background: loading || !inputValue.trim() ? '#1E2A3A' : 'linear-gradient(135deg, #0EA5E9, #0284C7)',
                  color: 'white',
                  boxShadow: loading || !inputValue.trim() ? 'none' : '0 0 20px #0EA5E930',
                }}
              >
                {loading ? <Loader2 size={15} className="animate-spin" /> : <Shield size={15} />}
                {loading ? 'Analyzing...' : 'Analyze Content'}
              </button>
            </div>
          </div>

          {error && (
            <div className="rounded-xl p-4 flex items-start gap-3" style={{ backgroundColor: '#EF444410', border: '1px solid #EF444430' }}>
              <AlertTriangle size={16} style={{ color: '#EF4444' }} className="mt-0.5 flex-shrink-0" />
              <p className="text-sm" style={{ color: '#FCA5A5' }}>{error}</p>
            </div>
          )}

          {result && levelStyle && LevelIcon && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
              <div className="lg:col-span-1 rounded-2xl p-6 flex flex-col items-center gap-4" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
                <RiskMeter score={result.risk_score} level={result.risk_level} size="lg" />
                <div className="w-full space-y-2">
                  <div className="flex justify-between text-xs">
                    <span style={{ color: '#64748B' }}>Words analyzed</span>
                    <span className="text-white font-medium">{result.word_count}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span style={{ color: '#64748B' }}>Content type</span>
                    <span className="text-white font-medium capitalize">{result.content_type}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span style={{ color: '#64748B' }}>Terms flagged</span>
                    <span className="text-white font-medium">{result.keywords_detected.length}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span style={{ color: '#64748B' }}>Status</span>
                    <span className="font-medium" style={{ color: result.is_flagged ? '#EF4444' : '#22C55E' }}>
                      {result.is_flagged ? 'Flagged' : 'Cleared'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-2 space-y-4">
                <div className="rounded-2xl p-5" style={{ backgroundColor: levelStyle.bg, border: `1px solid ${levelStyle.border}` }}>
                  <div className="flex items-start gap-3">
                    <LevelIcon size={16} style={{ color: levelStyle.iconColor }} className="mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-white mb-1">Analysis Summary</p>
                      <p className="text-xs leading-relaxed" style={{ color: '#CBD5E1' }}>{result.summary}</p>
                    </div>
                  </div>
                </div>

                {result.recommendation && (
                  <div className="rounded-2xl p-5" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
                    <p className="text-xs font-semibold mb-2" style={{ color: '#64748B' }}>RECOMMENDATION</p>
                    <p className="text-sm" style={{ color: '#CBD5E1' }}>{result.recommendation}</p>
                  </div>
                )}

                <div className="rounded-2xl p-5" style={{ backgroundColor: '#161B27', border: '1px solid #1E2A3A' }}>
                  <p className="text-xs font-semibold mb-4" style={{ color: '#64748B' }}>CATEGORY BREAKDOWN</p>
                  <CategoryBreakdown categories={result.categories} />
                </div>
              </div>
            </div>
          )}

          {!result && !loading && (
            <div className="text-center py-16">
              <div
                className="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-4"
                style={{ backgroundColor: '#0EA5E910', border: '1px solid #0EA5E920' }}
              >
                <Shield size={36} style={{ color: '#0EA5E9' }} />
              </div>
              <p className="text-white font-semibold text-lg">Ready to Analyze</p>
              <p className="text-sm mt-2 max-w-md mx-auto" style={{ color: '#64748B' }}>
                Paste any content — social media posts, video captions, messages, emails, or a website URL — to detect harmful or riot-provoking content.
              </p>
              <div className="flex items-center justify-center gap-6 mt-6">
                {['Hate Speech', 'Riot Provocation', 'Violence', 'Extremism', 'Threats'].map(tag => (
                  <span key={tag} className="text-xs px-3 py-1 rounded-full" style={{ backgroundColor: '#1E2A3A', color: '#64748B' }}>{tag}</span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
